/**
 * @file CrPsDataPool.c
 *
 * @author FW Profile code generator version 5.23
 * @date Created on: May 19 2019 17:58:46
 */

/* CrPsDataPool function definitions */
#include "CrPsDataPool.h"

/* FW Profile function definitions */
#include "FwSmDCreate.h"
#include "FwSmConfig.h"

#include <stdlib.h>

/* ----------------------------------------------------------------------------------------------------------------- */
FwSmDesc_t CrPsDataPoolCreate(void* smData)
{
	const FwSmCounterU2_t N_OUT_OF_READY = 2;	/* The number of transitions out of state READY */
	const FwSmCounterU2_t N_OUT_OF_LOADING = 1;	/* The number of transitions out of state LOADING */

	/** Create state machine smDesc */
	FwSmDesc_t smDesc = FwSmCreate(
		2,	/* NSTATES - The number of states */
		0,	/* NCPS - The number of choice pseudo-states */
		4,	/* NTRANS - The number of transitions */
		3,	/* NACTIONS - The number of state and transition actions */
		1	/* NGUARDS - The number of transition guards */
	);

	/** Configure the state machine smDesc */
	FwSmSetData(smDesc, smData);
	FwSmAddState(smDesc, CrPsDataPool_READY, N_OUT_OF_READY, NULL, NULL, NULL, NULL);
	FwSmAddState(smDesc, CrPsDataPool_LOADING, N_OUT_OF_LOADING, &CrPsDataPoolStartLoading, NULL, &CrPsDataPoolContLoading, NULL);
	FwSmAddTransStaToSta(smDesc, Load, CrPsDataPool_READY, CrPsDataPool_LOADING, NULL, NULL);
	FwSmAddTransStaToSta(smDesc, Refresh, CrPsDataPool_READY, CrPsDataPool_READY, &CrPsDataPoolRefresh, NULL);
	FwSmAddTransIpsToSta(smDesc, CrPsDataPool_READY, NULL);
	FwSmAddTransStaToSta(smDesc, Execute, CrPsDataPool_LOADING, CrPsDataPool_READY, NULL, &CrPsDataPoolHasLoadingTerm);

	return smDesc;
}

